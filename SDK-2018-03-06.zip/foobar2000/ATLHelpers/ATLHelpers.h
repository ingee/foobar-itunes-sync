#pragma once

#include "ATLHelpersLean.h"

// #pragma message("Avoid using this header. #include ATLHelpersLean.h then individual helpers instead")

#include "../helpers/helpers.h"

#include "WTL-PP.h"
#include "misc.h"
#include "GDIUtils.h"

#include "WindowPositionUtils.h"
#include "CDialogResizeHelper.h"

#include "BumpableElem.h"

#include "inplace_edit.h"
#include "inplace_edit_v2.h"

#include "AutoComplete.h"

#include "Controls.h"