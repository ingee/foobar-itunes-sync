#pragma once

#include "../SDK/foobar2000-winver.h"

#define _SECURE_ATL 1

#include "../SDK/foobar2000.h"

#include <atlbase.h>
#include <atltypes.h>
#include <atlstr.h>
#include <atlapp.h>
#include <atlctrls.h>
#include <atlwin.h>
#include <atlcom.h>
#include <atlcrack.h>
