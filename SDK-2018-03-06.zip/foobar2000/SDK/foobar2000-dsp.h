#pragma once

// placeholder added for foobar2000 mobile source compatibility

#include "foobar2000.h"