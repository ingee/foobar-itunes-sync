//cpp used to generate precompiled header
#include "foobar2000.h"