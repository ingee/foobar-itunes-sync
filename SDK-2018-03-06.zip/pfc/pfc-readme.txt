PFC : Peter's Foundation Classes

A library of loosely connected classes used by foobar2000 codebase; freely available and reusable for other projects.

PFC is not state-of-art code. Many parts of it exist only to keep old bits of foobar2000 codebase ( also third party foobar2000 components ) compiling without modification. For an example, certain classes predating 'pfc' namespace use exist outside the namespace.
